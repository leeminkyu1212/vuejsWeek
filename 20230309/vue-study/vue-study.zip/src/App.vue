<template>
  <div id="app">
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/board">board</router-link> |
    </nav>
    <router-view/>
  </div>
</template>


<script>
export default {

}
</script>

<style>

</style>